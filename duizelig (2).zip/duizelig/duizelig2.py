# Duizelig2

i = 1
while i <= 12:
    print(str(i) + 'AM')
    i = i + 1
while i <= 24:
    print(str(i - 12) + 'PM')
    i = i + 1